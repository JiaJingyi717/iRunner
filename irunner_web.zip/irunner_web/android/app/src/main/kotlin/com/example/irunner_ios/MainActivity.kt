package com.example.irunner_ios

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
